-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: share_creators
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `workspace_activation_code`
--

DROP TABLE IF EXISTS `workspace_activation_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workspace_activation_code` (
  `id` char(36) NOT NULL,
  `code` int(6) DEFAULT NULL,
  `user_email` varchar(200) DEFAULT NULL,
  `created_at` int(20) DEFAULT NULL,
  `updated_at` int(20) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workspace_activation_code`
--

LOCK TABLES `workspace_activation_code` WRITE;
/*!40000 ALTER TABLE `workspace_activation_code` DISABLE KEYS */;
INSERT INTO `workspace_activation_code` VALUES ('0843ce64-9353-11e9-b954-0618e20d3570',955033,'apoorvartist+3019@gmail.com',1561032044,1561032044,1),('bc557108-a7f5-11e9-8bb9-0618e20d3570',123456,'apoorvemployer+70@gmail.cocm',1563300948,1563300948,1),('c0cd51c8-b2a0-11e9-b6ac-0618e20d3570',123456,'apoorvartist+00001@gmail.com',1564473911,1564473911,1),('e041549a-a333-11e9-89e6-0618e20d3570',123456,'apoorvemployer+400@gmail.com',1562777881,1562777881,1),('e09e7ade-a334-11e9-bd32-0618e20d3570',123456,'apoorvemployer+400@gmail.com',1562778311,1562778311,1),('e27f424e-a3ce-11e9-9998-0618e20d3570',123456,'apoorvartist+5031@gmail.com',1562844457,1562844457,1),('ea96ae9c-a403-11e9-b8df-0618e20d3570',123456,'adaliu+21@sharecreators.com',1562867233,1562867233,1),('ec0fe9d0-9c9e-11e9-a4de-0618e20d3570',123456,'apoorvartist+3084@gmail.com',1562054199,1562054199,1),('edb63e20-9d47-11e9-86c9-0618e20d3570',123456,'adaliu+5@sharecreators.com',1562126786,1562126786,1),('ef9f6e54-9ccb-11e9-a258-0618e20d3570',123456,'apoorvartist+3095@gmail.com',1562073532,1562073532,1),('f219a6e6-a3cd-11e9-b029-0618e20d3570',123456,'apoorvemployer@gmail.com',1562844053,1562844053,1),('f49e960c-9e77-11e9-b098-0618e20d3570',123456,'adaliu+8@sharecreators.com',1562257365,1562257365,1),('f4c679c8-a15c-11e9-9d8f-0618e20d3570',123456,'apoorvemployer+500@gmail.com',1562575622,1562575622,1),('f6f48482-9ccb-11e9-9c13-0618e20d3570',123456,'apoorvartist+3095@gmail.com',1562073544,1562073544,1),('f87e5cf8-a20a-11e9-9ca2-0618e20d3570',123456,'xyz@xyz.com',1562650361,1562650361,1),('fb601f52-a40c-11e9-a06a-0618e20d3570',123456,'apoorvemployer+800@gmail.com',1562871127,1562871127,1),('ff3689d4-a332-11e9-9c69-0618e20d3570',123456,'apoorvemployer+400@gmail.com',1562777503,1562777503,1),('ffa72acc-a15c-11e9-949a-0618e20d3570',123456,'apoorvemployer+500@gmail.com',1562575640,1562575640,1);
/*!40000 ALTER TABLE `workspace_activation_code` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-20 11:46:06
