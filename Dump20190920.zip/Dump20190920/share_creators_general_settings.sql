-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: share_creators
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `general_settings`
--

DROP TABLE IF EXISTS `general_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `general_settings` (
  `id` char(36) NOT NULL,
  `module_name` varchar(100) NOT NULL,
  `value` text,
  `created_at` int(20) DEFAULT NULL,
  `updated_at` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `general_settings`
--

LOCK TABLES `general_settings` WRITE;
/*!40000 ALTER TABLE `general_settings` DISABLE KEYS */;
INSERT INTO `general_settings` VALUES ('bc626g73-7b7d-4efc-57d6-24737935b979','portfolio_admin_layout','[{\"x\":0,\"y\":0,\"w\":1,\"h\":1,\"i\":0,\"id\":\"4b789626-e767-11e8-a6b4-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":0,\"w\":1,\"h\":1,\"i\":1,\"id\":\"c98473b4-e767-11e8-98be-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":1,\"w\":1,\"h\":1,\"i\":2,\"id\":\"a103df9e-e774-11e8-bd2c-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":1,\"w\":1,\"h\":1,\"i\":3,\"id\":\"afc030fa-e774-11e8-b5a0-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":2,\"w\":1,\"h\":1,\"i\":4,\"id\":\"bafe7008-e774-11e8-9f30-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":2,\"w\":1,\"h\":1,\"i\":5,\"id\":\"c98e8928-e774-11e8-b834-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":3,\"w\":1,\"h\":1,\"i\":6,\"id\":\"d36cb280-e774-11e8-9763-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":3,\"w\":1,\"h\":1,\"i\":7,\"id\":\"ddbaa3dc-e774-11e8-bec8-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":4,\"w\":1,\"h\":1,\"i\":8,\"id\":\"e7284258-e774-11e8-ba75-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":4,\"w\":1,\"h\":1,\"i\":9,\"id\":\"f0149e0c-e774-11e8-93c4-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":5,\"w\":1,\"h\":1,\"i\":10,\"id\":\"fb743eb0-e774-11e8-936d-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":5,\"w\":1,\"h\":1,\"i\":11,\"id\":\"9a23d95c-ef1e-11e8-ba3f-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":6,\"w\":1,\"h\":1,\"i\":12,\"id\":\"76986e52-f3cf-11e8-97f1-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":6,\"w\":1,\"h\":1,\"i\":13,\"id\":\"03413706-f4cc-11e8-bcb8-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":7,\"w\":1,\"h\":1,\"i\":14,\"id\":\"68fbe966-f7be-11e8-9beb-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":7,\"w\":1,\"h\":1,\"i\":15,\"id\":\"f56b2af2-f849-11e8-bac0-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":8,\"w\":1,\"h\":1,\"i\":16,\"id\":\"0cb62f54-f84a-11e8-95c9-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":8,\"w\":1,\"h\":1,\"i\":17,\"id\":\"85f03d58-f93d-11e8-b535-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":9,\"w\":1,\"h\":1,\"i\":18,\"id\":\"e7119482-fa10-11e8-b001-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":9,\"w\":1,\"h\":1,\"i\":19,\"id\":\"02815bd0-fa11-11e8-81e4-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":10,\"w\":1,\"h\":1,\"i\":20,\"id\":\"7f9f5cd8-fa21-11e8-a022-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":10,\"w\":1,\"h\":1,\"i\":21,\"id\":\"b1e0c43e-fa21-11e8-a619-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":11,\"w\":1,\"h\":1,\"i\":22,\"id\":\"f7beec82-0201-11e9-84fe-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":11,\"w\":1,\"h\":1,\"i\":23,\"id\":\"bec90698-09da-11e9-94a8-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":12,\"w\":1,\"h\":1,\"i\":24,\"id\":\"0f52ce52-1005-11e9-a9d4-0618e20d3570\",\"moved\":false},{\"x\":1,\"y\":12,\"w\":1,\"h\":1,\"i\":25,\"id\":\"834cf722-23c6-11e9-97bd-0618e20d3570\",\"moved\":false},{\"x\":0,\"y\":13,\"w\":1,\"h\":1,\"i\":26,\"id\":\"e3ffc21e-2fa3-11e9-a20a-0618e20d3570\",\"moved\":false}]',1539273545,1550071690);
/*!40000 ALTER TABLE `general_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-20 11:46:03
