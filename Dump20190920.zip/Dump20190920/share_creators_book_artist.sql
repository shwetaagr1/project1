-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: share_creators
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book_artist`
--

DROP TABLE IF EXISTS `book_artist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book_artist` (
  `id` char(36) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `created_at` int(20) DEFAULT NULL,
  `updated_at` int(20) DEFAULT NULL,
  `booked_at` int(20) DEFAULT NULL,
  `rating` varchar(30) DEFAULT NULL,
  `tags` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_artist`
--

LOCK TABLES `book_artist` WRITE;
/*!40000 ALTER TABLE `book_artist` DISABLE KEYS */;
INSERT INTO `book_artist` VALUES ('1009e936-381c-11e9-b8c6-0618e20d3570','new book artist','apoorvartist+0300@gmail.com',1551002879,1551002879,NULL,NULL,NULL),('1074e182-381c-11e9-a953-0618e20d3570','new book artist 1','apoorvartist+0301@gmail.com',1551002880,1551002880,NULL,NULL,NULL),('1527ea30-380d-11e9-bec3-0618e20d3570','qwerty','apoorvartist+0286@gmail.com',1550996445,1550996445,NULL,NULL,NULL),('1e0d77ac-1993-11e9-9c1e-0618e20d3570','apoorv10','apoorvartist+1210@gmail.com',1547727031,1551002879,NULL,'5',NULL),('1fb737ce-103c-11e9-aabb-0618e20d3570','already registered user','apoorvartist+1072@gmail.com',1546618603,1551002878,NULL,'5','design'),('79f90d46-1d77-11e9-a39e-0618e20d3570','apoorv11','apoorvartist+1211@gmail.com',1548073460,1551002879,NULL,'5',NULL),('9dcef226-35be-11e9-9baa-0618e20d3570','check artists 1','apoorvartist+0022@gmail.com',1550742842,1550742842,NULL,NULL,NULL),('9e3ae4a4-35be-11e9-ac22-0618e20d3570','checkartist2','apoorvartist+026@gmail.com',1550742843,1550742843,NULL,NULL,NULL),('b4a4fb82-1a3c-11e9-82bb-0618e20d3570','apoorv9','apoorvartist+1212@gmail.com',1547727031,1551002879,NULL,'5',NULL),('c1fada20-1048-11e9-8359-0618e20d3570','umagine new','shwetaagr84+183@gmail.com',1547727026,1551002878,NULL,'5','developer'),('dfa72422-1a50-11e9-81e1-0618e20d3570','Apoorv 2','apoorvartist+1214@gmail.com',1547727027,1551002878,NULL,'5',NULL),('e010ce90-1a50-11e9-aa9f-0618e20d3570','apoorv3','apoorvartist+1216@gmail.com',1547727027,1551002878,NULL,'5',NULL),('e07a60b2-1a50-11e9-9be2-0618e20d3570','apoorv4','apoorvartist+1218@gmail.com',1547727028,1551002879,NULL,'5',NULL),('e0e39ad2-1a50-11e9-ada4-0618e20d3570','apoorv5','apoorvartist+1220@gmail.com',1547727029,1551002879,NULL,'5',NULL),('e14dcb28-1a50-11e9-80eb-0618e20d3570','apoorv6','apoorvartist+1222@gmail.com',1547727029,1551002879,NULL,'5',NULL),('e1b99178-1a50-11e9-86a4-0618e20d3570','apoorv7','apoorvartist+1224@gmail.com',1547727030,1551002879,NULL,'5',NULL),('e223d024-1a50-11e9-af8d-0618e20d3570','apoorv8','apoorvartist+1226@gmail.com',1547727031,1551002879,NULL,'5',NULL),('e47ca550-14ae-11e9-b093-0618e20d3570','already registered user 2','apoorvartist+1074@gmail.com',1547107700,1551002878,NULL,'5','design'),('f924be04-101f-11e9-a08e-0618e20d3570','shweta agr','shwetaagr84+180@gmail.com',1546606512,1551002878,NULL,'5','graphic'),('f9911d74-101f-11e9-8914-0618e20d3570','Shweta agrawal','shwetaagr84+181@gmail.com',1546606513,1551002878,NULL,'5','design');
/*!40000 ALTER TABLE `book_artist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-20 11:46:03
