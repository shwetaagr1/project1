-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: share_creators
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notifications_preferences`
--

DROP TABLE IF EXISTS `notifications_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications_preferences` (
  `id` char(36) NOT NULL,
  `notification_owner` enum('employer','artist') NOT NULL,
  `notification_rule` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications_preferences`
--

LOCK TABLES `notifications_preferences` WRITE;
/*!40000 ALTER TABLE `notifications_preferences` DISABLE KEYS */;
INSERT INTO `notifications_preferences` VALUES ('0fd69c4c-c1be-414a-abcf-9d5a69a501ed','employer','Payment is processed',NULL,NULL),('3a4e9f98-2d8e-4592-8f23-99ae37988c2c','artist','Someone invited me to view the job post',NULL,NULL),('3abcf5b6-54bb-4c84-bf89-5d7725250851','artist','Recommended jobs fit for my skillsets',NULL,NULL),('5d1b7ed0-1554-4fd0-8a02-dd346019489b','artist','Someone wants to hire me',NULL,NULL),('8651321f-e7ba-4d69-8fcd-16be74bfb40b','employer','System notification',NULL,NULL),('8a7d668b-38fb-47ff-9b9d-d9ccc84ff893','artist','Email notification when applied jobs uploaded',NULL,NULL),('a7669fca-f88f-47db-b9ce-94ee2d82cc10','artist','Email notification when open jobs’ employers left messages',NULL,NULL),('c58f6e38-e4d1-4530-bc49-bfae12d2221d','artist','Email notification when open jobs’ employers reviewed works',NULL,NULL),('c674fe4d-5926-4672-a3b6-d177c0b45ad3','artist','System notification',NULL,NULL),('cccd6a03-bd04-441c-a4fd-48cb8d1f86ea','artist','Payment is processed',NULL,NULL),('cd8ac2a6-c2e7-4b40-86c0-936ea32c5fcb','artist','Email notification when applied jobs responsed by employer',NULL,NULL);
/*!40000 ALTER TABLE `notifications_preferences` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-20 11:46:14
