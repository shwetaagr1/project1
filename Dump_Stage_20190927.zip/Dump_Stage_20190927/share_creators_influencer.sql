-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: db-sc-stage.sharecreators.com    Database: share_creators
-- ------------------------------------------------------
-- Server version	5.7.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `influencer`
--

DROP TABLE IF EXISTS `influencer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `influencer` (
  `id` char(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `link` varchar(300) DEFAULT NULL,
  `user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `influencer`
--

LOCK TABLES `influencer` WRITE;
/*!40000 ALTER TABLE `influencer` DISABLE KEYS */;
INSERT INTO `influencer` VALUES ('097195e4-ee4b-11e8-b487-0618e20d3570','ttttt',1542886668,1542886668,'http://www-stage.sharecreators.com/ref/097195e4-ee4b-11e8-b487-0618e20d3570:WELCOME18:ttttt','5770a42e-68e5-11e8-a944-28cfe94d206d'),('0cf4d8fc-ee4b-11e8-9422-0618e20d3570','uuuuu',1542886674,1542886674,'http://www-stage.sharecreators.com/ref/0cf4d8fc-ee4b-11e8-9422-0618e20d3570:WELCOME18:uuuuu','5770a42e-68e5-11e8-a944-28cfe94d206d'),('112957ea-ecb1-11e8-a81b-0618e20d3570','apoorv',1542710587,1542710587,'http://www-stage.sharecreators.com/ref/97647e38-67e7-11e8-90ce-28cfe94d206d:WELCOME18:apoorv','5770a42e-68e5-11e8-a944-28cfe94d206d'),('391ae6e8-ee31-11e8-b971-0618e20d3570','hujikolkjuik',1542875581,1542875581,'http://www-stage.sharecreators.com/ref/391ae6e8-ee31-11e8-b971-0618e20d3570:WELCOME18:hujikolkjuik','5770a42e-68e5-11e8-a944-28cfe94d206d'),('45e69044-ee21-11e8-8a52-0618e20d3570','oliyhuyiuyhuyiuh',1542868730,1542868730,'http://www-stage.sharecreators.com/ref/45e69044-ee21-11e8-8a52-0618e20d3570:WELCOME18:oliyhuyiuyhuyiuh','5770a42e-68e5-11e8-a944-28cfe94d206d'),('70c48ec8-0457-11e9-91e5-0618e20d3570','apoorvartist@gmail.com',1545310921,1545310921,'http://www-stage.sharecreators.com/ref/70c48ec8-0457-11e9-91e5-0618e20d3570:WELCOME18:apoorvartist@gmail.com','5770a42e-68e5-11e8-a944-28cfe94d206d'),('747aa67a-05d7-11e9-b5b7-0618e20d3570','apoorvartist+1030@gmail.com',1545475854,1545475854,'http://www-stage.sharecreators.com/ref/747aa67a-05d7-11e9-b5b7-0618e20d3570:WELCOME18:apoorvartist+1030@gmail.com','9e5b0960-05d4-11e9-aea9-0618e20d3570'),('77233326-0459-11e9-b05d-0618e20d3570','apoorv',1545311790,1545311790,'http://www-stage.sharecreators.com/ref/77233326-0459-11e9-b05d-0618e20d3570:WELCOME18:apoorv','5770a42e-68e5-11e8-a944-28cfe94d206d'),('7bb04098-ecb5-11e8-9446-0618e20d3570','employer',1542712484,1542712484,'http://www-stage.sharecreators.com/ref/97647e38-67e7-11e8-90ce-28cfe94d206d:WELCOME18:employer','5770a42e-68e5-11e8-a944-28cfe94d206d'),('7beba618-ecb2-11e8-a74d-0618e20d3570','artist test',1542711196,1542711196,'http://www-stage.sharecreators.com/ref/97647e38-67e7-11e8-90ce-28cfe94d206d:WELCOME18:artist test','5770a42e-68e5-11e8-a944-28cfe94d206d'),('84d15b48-f495-11e8-b948-0618e20d3570','apoorv',1543578365,1543578365,'http://www-stage.sharecreators.com/ref/84d15b48-f495-11e8-b948-0618e20d3570:WELCOME18:apoorv','5770a42e-68e5-11e8-a944-28cfe94d206d'),('8c45e5c0-0ffb-11e9-a76c-0618e20d3570','ythdsretwrefsdraes@hrgfcxgfvhg.com',1546590867,1546590867,'http://www-stage.sharecreators.com/ref/8c45e5c0-0ffb-11e9-a76c-0618e20d3570:WELCOME18:ythdsretwrefsdraes@hrgfcxgfvhg.com','cc621306-0ff9-11e9-a0e3-0618e20d3570'),('9093ab6e-ee2f-11e8-b708-0618e20d3570','lkhuy',1542874869,1542874869,'http://www-stage.sharecreators.com/ref/9093ab6e-ee2f-11e8-b708-0618e20d3570:WELCOME18:lkhuy','5770a42e-68e5-11e8-a944-28cfe94d206d'),('91c81774-ee55-11e8-8dd5-0618e20d3570','referral test 3',1542891192,1542891192,'http://www-stage.sharecreators.com/ref/91c81774-ee55-11e8-8dd5-0618e20d3570:WELCOME18:referral test 3','5770a42e-68e5-11e8-a944-28cfe94d206d'),('96291844-05d5-11e9-aa28-0618e20d3570','apoorvartist+1030@gmail.com',1545475051,1545475051,'http://www-stage.sharecreators.com/ref/96291844-05d5-11e9-aa28-0618e20d3570:WELCOME18:apoorvartist+1030@gmail.com','9e5b0960-05d4-11e9-aea9-0618e20d3570'),('9787f9d8-045b-11e9-a5de-0618e20d3570','apoorvartist+1002@gmail.com',1545312704,1545312704,'http://www-stage.sharecreators.com/ref/9787f9d8-045b-11e9-a5de-0618e20d3570:WELCOME18:apoorvartist+1002@gmail.com','5770a42e-68e5-11e8-a944-28cfe94d206d'),('981777f8-04e1-11e9-8746-0618e20d3570','shruti2@ff.com',1545370257,1545370257,'http://www-stage.sharecreators.com/ref/981777f8-04e1-11e9-8746-0618e20d3570:WELCOME18:shruti2@ff.com','5770a42e-68e5-11e8-a944-28cfe94d206d'),('a05fc8d0-ef1e-11e8-bf67-0618e20d3570','l;kljkhugyfd',1542977545,1542977545,'http://www-stage.sharecreators.com/ref/a05fc8d0-ef1e-11e8-bf67-0618e20d3570:WELCOME18:l;kljkhugyfd','5770a42e-68e5-11e8-a944-28cfe94d206d'),('a33cf712-ef1e-11e8-9513-0618e20d3570','k;jlkht',1542977550,1542977550,'http://www-stage.sharecreators.com/ref/a33cf712-ef1e-11e8-9513-0618e20d3570:WELCOME18:k;jlkht','5770a42e-68e5-11e8-a944-28cfe94d206d'),('a5c0c57c-ef1e-11e8-a7d3-0618e20d3570','jkhjghfgdfds',1542977554,1542977554,'http://www-stage.sharecreators.com/ref/a5c0c57c-ef1e-11e8-a7d3-0618e20d3570:WELCOME18:jkhjghfgdfds','5770a42e-68e5-11e8-a944-28cfe94d206d'),('ad2632a4-ee54-11e8-a8e7-0618e20d3570','referral test',1542890808,1542890808,'http://www-stage.sharecreators.com/ref/ad2632a4-ee54-11e8-a8e7-0618e20d3570:WELCOME18:referral test','5770a42e-68e5-11e8-a944-28cfe94d206d'),('aee8bdea-ecac-11e8-86b3-0618e20d3570','apoorv',1542708704,1542708704,'http://www-stage.sharecreators.com/ref/83f2d6f8-eca1-11e8-82ca-0618e20d3570:WELCOME18:apoorv','5770a42e-68e5-11e8-a944-28cfe94d206d'),('b64e8134-0451-11e9-9af7-0618e20d3570','apoorvartist@gmail.com',1545308460,1545308460,'http://www-stage.sharecreators.com/ref/b64e8134-0451-11e9-9af7-0618e20d3570:WELCOME18:apoorvartist@gmail.com','5770a42e-68e5-11e8-a944-28cfe94d206d'),('baf23aa4-0a8d-11e9-ad7c-0618e20d3570','apoorvartist+125@Gmail.com',1545993945,1545993945,'http://www-stage.sharecreators.com/ref/baf23aa4-0a8d-11e9-ad7c-0618e20d3570:WELCOME18:apoorvartist+125@Gmail.com','88aacc5a-0907-11e9-898b-0618e20d3570'),('beb4fecc-09db-11e9-b60d-0618e20d3570','apoorv',1545917501,1545917501,'http://www-stage.sharecreators.com/ref/beb4fecc-09db-11e9-b60d-0618e20d3570:WELCOME18:apoorv','5770a42e-68e5-11e8-a944-28cfe94d206d'),('d7a37032-0ab5-11e9-a73b-0618e20d3570','thrgeset@gtrdsthrefd.com',1546011173,1546011173,'http://www-stage.sharecreators.com/ref/d7a37032-0ab5-11e9-a73b-0618e20d3570:WELCOME18:thrgeset@gtrdsthrefd.com','953a6566-0907-11e9-91b6-0618e20d3570'),('edfc7b70-ee50-11e8-b19d-0618e20d3570','test  by apporv',1542889199,1542889199,'http://www-stage.sharecreators.com/ref/edfc7b70-ee50-11e8-b19d-0618e20d3570:WELCOME18:test  by apporv','5770a42e-68e5-11e8-a944-28cfe94d206d'),('f8a81d88-0451-11e9-b232-0618e20d3570','apoorvemployer@gmail.com',1545308572,1545308572,'http://www-stage.sharecreators.com/ref/f8a81d88-0451-11e9-b232-0618e20d3570:WELCOME18:apoorvemployer@gmail.com','5770a42e-68e5-11e8-a944-28cfe94d206d'),('fdccca10-0ab5-11e9-94d2-0618e20d3570','apoorvartist@gmail.com',1546011237,1546011237,'http://www-stage.sharecreators.com/ref/fdccca10-0ab5-11e9-94d2-0618e20d3570:WELCOME18:apoorvartist@gmail.com','953a6566-0907-11e9-91b6-0618e20d3570');
/*!40000 ALTER TABLE `influencer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-27 13:43:40
