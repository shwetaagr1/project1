-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: db-sc-stage.sharecreators.com    Database: share_creators
-- ------------------------------------------------------
-- Server version	5.7.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL COMMENT 'Category name',
  `title` varchar(255) NOT NULL COMMENT 'URL compatible title for category',
  `parent_id` char(36) DEFAULT NULL,
  `created_at` int(20) NOT NULL,
  `updated_at` int(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES ('0959b61e-5f61-11e8-9044-28cfe94d206d','Test Cat','cat-test','565d54cc-5e7e-11e8-8874-28cfe94d206d',1527173100,1527173100),('0a7444fe-5905-11e8-b839-fcaa14641442','Story writer','story-writer','f8f085e4-5904-11e8-8c5a-fcaa14641442',1526473882,1526473882),('4b6bed44-5e7e-11e8-9846-28cfe94d206d','Design','design','',1527075715,1527075715),('565d54cc-5e7e-11e8-8874-28cfe94d206d','Design','design-c','',1527075734,1527075734),('c2548954-5904-11e8-92fc-fcaa14641442','Advertising/Design','advertising-design','',1526473761,1526473761),('d6de19a8-5904-11e8-95df-fcaa14641442','Animator','animator','c2548954-5904-11e8-92fc-fcaa14641442',1526473795,1526473795),('ead293c6-5904-11e8-814d-fcaa14641442','3D Artist','3d-artist','c2548954-5904-11e8-92fc-fcaa14641442',1526473828,1526473828),('f8f085e4-5904-11e8-8c5a-fcaa14641442','Game','game','',1526473852,1526473852);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-27 13:41:45
